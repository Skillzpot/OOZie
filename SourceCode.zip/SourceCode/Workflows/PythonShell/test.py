import sys

print ("Hello World!")
print sys.argv[1]
